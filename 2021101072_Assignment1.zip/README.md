I compiled the codes on MAC OS, using the following commands on my terminal.

GITHUB REPO LINK: https://github.com/ashnadua01/ISS_Assignment1

Q1. 
    Both parts are included in one shell script file named Q1.sh

    Commands:
        chmod +x ./q1.sh
        ./q1.sh

    Input:
        N.A.

    Output:
        Displayed on Terminal

Q2.
    Included in one shell script file named Q2.sh
    (quotes.txt file had some lines of the form "quote"~ "author",
    and some lines were of the form "quote" ~ "author", therfore the 
    output shows an extra space after the full stop in speech.txt, 
    due to different type of input available.)

    Commands:
        chmod +x ./q2.sh
        ./q2.sh

    Input:
        N.A.

    Output:
        Output is saved in a file named speech.txt

Q3.
    All parts are included in one shell script file named Q3.sh

    Commands:
        chmod +x ./q3.sh
        ./q3.sh
    
    Input:
        quotes.txt (Name of any file)
    
    Output:
        Displayed on Terminal

Q4.
    Included in one shell script named Q4.sh

    Commands:
        chmod +x ./q4.sh
        ./q4.sh

    Input:
        21,22,34,1,7,90,101,2,4,8,45 (List of numbers with commas to sort)

    Output:
        Displayed on Terminal

Q5.
    All parts included in one shell script named Q5.sh

    Commands:
        chmod x ./q5.sh
        ./q5.sh
    
    Input:
        Helloo (Any String, with even number of letters)

    Output:
        Displayed on Terminal







